# -*- coding: utf-8 -*-
from machine import Pin, I2C
import time
import xbee

# Configuración de pines
led_pin = Pin("D12", Pin.OUT, value=0)

# Clase simplificada para pantalla OLED SSD1306 sin dependencia de framebuf
class SSD1306_Simple:
    def __init__(self, width, height, i2c, addr=0x3C):
        self.width = width
        self.height = height
        self.pages = height // 8
        self.i2c = i2c
        self.addr = addr
        self.temp = bytearray(2)
        self.buffer = bytearray(self.pages * width)
        self.init_display()
        
    def init_display(self):
        # Secuencia de inicialización para SSD1306
        for cmd in (
            0xAE,        # display off
            0x20, 0x00,  # horizontal addressing mode
            0x40,        # start line = 0
            0xA1,        # segment remap 127 to 0
            0xA8, 0x3F,  # multiplex ratio = height-1
            0xC8,        # COM scan direction remapped
            0xD3, 0x00,  # no display offset
            0xDA, 0x12,  # com pins hardware configuration
            0xD5, 0x80,  # clock div ratio
            0xD9, 0xF1,  # precharge period
            0xDB, 0x30,  # VCOMH deselect level
            0x81, 0xFF,  # max contrast
            0xA4,        # output RAM to display
            0xA6,        # normal display (vs inverse)
            0x8D, 0x14,  # charge pump enabled
            0xAF,        # display on
        ):
            self.write_cmd(cmd)
        self.clear()
        self.show()
    
    def write_cmd(self, cmd):
        self.temp[0] = 0x80  # Control byte: Co bit set, D/C=0 (command)
        self.temp[1] = cmd
        self.i2c.writeto(self.addr, self.temp)
    
    def clear(self):
        # Llenar el buffer con ceros para limpiar la pantalla
        for i in range(len(self.buffer)):
            self.buffer[i] = 0
    
    def show(self):
        # Configurar la dirección de columna y página
        self.write_cmd(0x21)  # set column address
        self.write_cmd(0)     # start at column 0
        self.write_cmd(self.width - 1)  # end at last column
        self.write_cmd(0x22)  # set page address
        self.write_cmd(0)     # start at page 0
        self.write_cmd(self.pages - 1)  # end at last page
        
        # Enviar buffer en chunks para XBee3
        chunk_size = 16
        for i in range(0, len(self.buffer), chunk_size):
            end = min(i + chunk_size, len(self.buffer))
            self.i2c.writeto(self.addr, b'\x40' + self.buffer[i:end])

    # ===== Patrones horizontales para letras =====
    # Cada byte representa una fila horizontal de 8 píxeles
    # Letra 'O'
    O_PATTERN = [
        0x3E, # 00111110
        0x63, # 01100011
        0x41, # 01000001
        0x41, # 01000001
        0x41, # 01000001
        0x41, # 01000001
        0x63, # 01100011
        0x3E, # 00111110
    ]
    
    # Letra 'N'
    N_PATTERN = [
        0x41, # 01000001
        0x61, # 01100001
        0x71, # 01110001
        0x59, # 01011001
        0x4D, # 01001101
        0x47, # 01000111
        0x43, # 01000011
        0x41, # 01000001
    ]
    
    # Letra 'F'
    F_PATTERN = [
        0x7F, # 01111111
        0x41, # 01000001
        0x40, # 01000000
        0x7C, # 01111100
        0x40, # 01000000
        0x40, # 01000000
        0x40, # 01000000
        0x40, # 01000000
    ]
    
    def draw_char(self, pattern, x, y):
        """Dibuja un carácter de 8x8 en la posición especificada"""
        for row in range(8):
            if y + row < self.height:
                page = (y + row) // 8
                offset = (y + row) % 8
                
                if page * self.width + x < len(self.buffer):
                    # Establecer el bit correspondiente en el buffer
                    mask = 1 << offset
                    
                    # Para cada columna del carácter (8 bits)
                    for col in range(8):
                        if x + col < self.width:
                            pixel_on = (pattern[row] & (0x80 >> col)) != 0
                            if pixel_on:
                                self.buffer[page * self.width + x + col] |= mask
    
    def display_on(self, x, y):
        """Dibuja "ON" en la posición especificada"""
        self.draw_char(self.O_PATTERN, x, y)
        self.draw_char(self.N_PATTERN, x + 10, y)
    
    def display_off(self, x, y):
        """Dibuja "OFF" en la posición especificada"""
        self.draw_char(self.O_PATTERN, x, y)
        self.draw_char(self.F_PATTERN, x + 10, y)
        self.draw_char(self.F_PATTERN, x + 20, y)
    
    def text(self, string, x, y):
        """Dibuja texto en la pantalla"""
        if string == "ON":
            self.display_on(x, y)
        elif string == "OFF":
            self.display_off(x, y)
        else:
            pass  # No implementamos otros textos

# Configuración del I2C para la pantalla OLED
try:
    i2c = I2C(1)  # En XBee3, usar 1 para el bus I2C disponible
    
    # Escanear dispositivos I2C
    devices = i2c.scan()
    if devices:
        print("Dispositivos I2C encontrados: {}".format([hex(d) for d in devices]))
        oled_addr = 0x3C  # Dirección estándar para la mayoría de pantallas OLED
        if 0x3C not in devices and 0x3D in devices:
            oled_addr = 0x3D  # Algunas pantallas usan esta dirección alternativa
            
        # Inicializar pantalla OLED
        oled = SSD1306_Simple(128, 32, i2c, addr=oled_addr)  # Ajustar a 32 pixels de altura
        
        def display_status(status):
            oled.clear()
            oled.text(status, 50, 12)  # Centrado en la pantalla
            oled.show()
            
        print("OLED inicializado correctamente")
    else:
        print("No se encontraron dispositivos I2C")
        def display_status(status):
            print("OLED (simulado): {}".format(status))
            
except Exception as e:
    print("Error al inicializar I2C: {}".format(e))
    def display_status(status):
        print("OLED (simulado): {}".format(status))

# Loop principal
while True:
    print("- LED OFF")
    led_pin.value(0)
    display_status("OFF")
    time.sleep(1)

    print("- LED ON")
    led_pin.value(1)
    display_status("ON")
    time.sleep(1)